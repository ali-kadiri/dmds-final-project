import os
import pandas as pd
from glob import glob
from sqlalchemy import create_engine

#Set up SQLAlchemy engine with your credentials
engine = create_engine("postgresql+psycopg2://postgres:31@localhost:5432/CitiBike2023")

#Path to your folder of CSVs
folder_path = r"C:\Users\Peasa\Desktop\Final\Citibike data"
csv_files = glob(os.path.join(folder_path, "*.csv"))

#Loop through all CSV files and append to existing citibike_trips table
for file in csv_files:
    print(f"Importing: {file}")
    df = pd.read_csv(file, low_memory=False)
    df.to_sql("citibike_trips", engine, if_exists="append", index=False, method="multi")

print("All files imported successfully.")
